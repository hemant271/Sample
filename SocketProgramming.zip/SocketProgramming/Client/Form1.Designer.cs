﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.message = new System.Windows.Forms.TextBox();
            this.Send = new System.Windows.Forms.Button();
            this.OutBox = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.Button();
            this.conn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // message
            // 
            this.message.Location = new System.Drawing.Point(32, 77);
            this.message.Name = "message";
            this.message.Size = new System.Drawing.Size(229, 20);
            this.message.TabIndex = 0;
            // 
            // Send
            // 
            this.Send.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Send.Location = new System.Drawing.Point(102, 128);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(75, 23);
            this.Send.TabIndex = 1;
            this.Send.Text = "Send";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // OutBox
            // 
            this.OutBox.AutoSize = true;
            this.OutBox.Location = new System.Drawing.Point(32, 188);
            this.OutBox.Name = "OutBox";
            this.OutBox.Size = new System.Drawing.Size(0, 13);
            this.OutBox.TabIndex = 2;
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(197, 12);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(75, 23);
            this.Close.TabIndex = 3;
            this.Close.Text = "Close";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // conn
            // 
            this.conn.Location = new System.Drawing.Point(49, 209);
            this.conn.Name = "conn";
            this.conn.Size = new System.Drawing.Size(165, 23);
            this.conn.TabIndex = 4;
            this.conn.Text = "Establish Connection Again";
            this.conn.UseVisualStyleBackColor = true;
            this.conn.Click += new System.EventHandler(this.conn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.conn);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.OutBox);
            this.Controls.Add(this.Send);
            this.Controls.Add(this.message);
            this.Name = "Form1";
            this.Text = "Client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox message;
        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.Label OutBox;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button conn;
    }
}

