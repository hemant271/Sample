﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Client
{
    public partial class Form1 : Form
    {
        private Socket sender = null;
        public Form1()
        {
            InitializeComponent();
            ExecuteClient();
        }

        private void Send_Click(object sendr, EventArgs e)
        {
            try
            {
                byte[] messageSent = Encoding.ASCII.GetBytes(message.Text);
                int byteSent = sender.Send(messageSent);

                byte[] messageReceived = new byte[1024];

                int byteRecv = sender.Receive(messageReceived);
                OutBox.Text =  string.Format("Message from Server -> {0}", Encoding.ASCII.GetString(messageReceived, 0, byteRecv));
                
            }

            catch (ArgumentNullException ane)
            {

                OutBox.Text = string.Format("ArgumentNullException : {0}", ane.ToString());
            }

            catch (SocketException se)
            {

                OutBox.Text = string.Format("SocketException : {0}", se.ToString());
            }

            catch (Exception el)
            {
                OutBox.Text = string.Format("Unexpected exception : {0}", el.ToString());
            }
        }

        public void ExecuteClient()
        {
            try
            {

                IPHostEntry ipHost = Dns.GetHostEntry(Dns.GetHostName());
                IPAddress ipAddr = ipHost.AddressList[0];
                IPEndPoint localEndPoint = new IPEndPoint(ipAddr, 11111);

                sender = new Socket(ipAddr.AddressFamily,
                           SocketType.Stream, ProtocolType.Tcp);
                sender.Connect(localEndPoint);
                OutBox.Text = string.Format("Socket connected to -> {0} ", sender.RemoteEndPoint.ToString());
            }

            catch (Exception e)
            {
                 Console.WriteLine(e.ToString());
            }
        }

        public void CloseSocket()
        {
            try
            {
                sender.Shutdown(SocketShutdown.Both);
                sender.Close();
                OutBox.Text = "Socket Closed";
            }
            catch (Exception ex)
            {
                OutBox.Text = "Unable to close Socket " + ex.Message;
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            CloseSocket();
        }

        private void conn_Click(object sender, EventArgs e)
        {
            ExecuteClient();
        }
    }
}
