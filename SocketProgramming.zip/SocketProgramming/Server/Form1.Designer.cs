﻿namespace Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OutBox = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.Button();
            this.Server = new System.Windows.Forms.Button();
            this.ClientMsgs = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // OutBox
            // 
            this.OutBox.AutoSize = true;
            this.OutBox.Location = new System.Drawing.Point(26, 46);
            this.OutBox.Name = "OutBox";
            this.OutBox.Size = new System.Drawing.Size(0, 13);
            this.OutBox.TabIndex = 0;
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(197, 13);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(75, 23);
            this.Close.TabIndex = 1;
            this.Close.Text = "Close";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click_1);
            // 
            // Server
            // 
            this.Server.Location = new System.Drawing.Point(197, 42);
            this.Server.Name = "Server";
            this.Server.Size = new System.Drawing.Size(75, 23);
            this.Server.TabIndex = 2;
            this.Server.Text = "Start Server";
            this.Server.UseVisualStyleBackColor = true;
            this.Server.Click += new System.EventHandler(this.Server_Click);
            // 
            // ClientMsgs
            // 
            this.ClientMsgs.Location = new System.Drawing.Point(-5, 71);
            this.ClientMsgs.Name = "ClientMsgs";
            this.ClientMsgs.Size = new System.Drawing.Size(290, 178);
            this.ClientMsgs.TabIndex = 3;
            this.ClientMsgs.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.ClientMsgs);
            this.Controls.Add(this.Server);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.OutBox);
            this.Name = "Form1";
            this.Text = "Server";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OutBox;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button Server;
        private System.Windows.Forms.RichTextBox ClientMsgs;
    }
}

