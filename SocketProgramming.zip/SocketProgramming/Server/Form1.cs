﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class Form1 : Form
    {
        private Socket receiver = null;
        private Socket clientSocket = null;
        public Form1()
        {
            InitializeComponent();
            OutBox.Text = "Program Started...";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public async Task ExecuteClient()
        {
            try
            {

                IPHostEntry ipHost = Dns.GetHostEntry(Dns.GetHostName());
                IPAddress ipAddr = ipHost.AddressList[0];
                IPEndPoint localEndPoint = new IPEndPoint(ipAddr, 11111);

                receiver = new Socket(ipAddr.AddressFamily,
                           SocketType.Stream, ProtocolType.Tcp);
                receiver.Bind(localEndPoint);
                receiver.Listen(10);
                // OutBox.Text = string.Format("Socket connected to -> {0} ", receiver.RemoteEndPoint.ToString());

                while (true)
                {

                    OutBox.Text = "Waiting connection ... ";

                    clientSocket = receiver.Accept();

                    while(true)
                    {
                        byte[] bytes = new Byte[1024];
                        string data = null;

                        int numByte = clientSocket.Receive(bytes);

                        data += Encoding.ASCII.GetString(bytes,
                                                   0, numByte);

                        if (!string.IsNullOrWhiteSpace(data))
                        {
                            ClientMsgs.Text = ClientMsgs.Text + (DateTime.Now + " -->" + data+"\n");
                            OutBox.Text = "Text Receive From Client";
                            byte[] message = Encoding.ASCII.GetBytes("Processed - " + data);

                            clientSocket.Send(message);
                        }
                    }
                }
            }

            catch (Exception e)
            {
                OutBox.Text = e.ToString();
            }
        }

        public void CloseSocket()
        {
            try
            {
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();
                OutBox.Text = "Socket Closed";
            }
            catch (Exception ex)
            {
                OutBox.Text = "Unable to close Socket " + ex.Message;
            }
        }

        private void Close_Click_1(object sender, EventArgs e)
        {
            CloseSocket();
        }

        private void Server_Click(object sender, EventArgs e)
        {
           Task.Run(()=>ExecuteClient());
        }
    }
}
